package com.cg.payroll.beans;
public class Associate {
	private int associateId;
	private int yearlyInvestmentUnder8oC;
	private String firstName,lastname,department,designation,pancard,emailid;
	public Salary salary;
	private BankDetails bankdetails;
	public Associate() {}
	public Associate(int associateId, int yearlyInvestmentUnder8oC, String firstName, String lastname, String department,
			String designation, String pancard, String emailid,Salary salary,BankDetails bankdetails) {
		super();
		this.associateId = associateId;
		this.yearlyInvestmentUnder8oC = yearlyInvestmentUnder8oC;
		this.firstName = firstName;
		this.lastname = lastname;
		this.department = department;
		this.designation = designation;
		this.pancard = pancard;
		this.emailid = emailid;
		this.salary=salary;
		this.bankdetails=bankdetails;
	}

	public Associate(int yearlyInvestmentUnder8oC, String firstName, String lastname, String department, String designation,String pancard, String emailid,Salary salary,BankDetails bankdetails) {
		super();
		this.yearlyInvestmentUnder8oC = yearlyInvestmentUnder8oC;
		this.firstName = firstName;
		this.lastname = lastname;
		this.department = department;
		this.designation = designation;
		this.pancard = pancard;
		this.emailid = emailid;
		this.salary=salary;
		this.bankdetails=bankdetails;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Associate other = (Associate) obj;
		if (bankdetails == null) {
			if (other.bankdetails != null)
				return false;
		} else if (!bankdetails.equals(other.bankdetails))
			return false;
		if (salary == null) {
			if (other.salary != null)
				return false;
		} else if (!salary.equals(other.salary))
			return false;
		return true;
	}
	public Salary getSalary() {
		return salary;
	}
	public void setSalary(Salary salary) {
		this.salary = salary;
	}
	public BankDetails getBankdetails() {
		return bankdetails;
	}
	public void setBankdetails(BankDetails bankdetails) {
		this.bankdetails = bankdetails;
	}
	public int getAssociateId() {
		return associateId;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public int getYearlyInvestmentUnder8oC() {
		return yearlyInvestmentUnder8oC;
	}
	public void setYearlyInvestmentUnder8oC(int yearlyInvestmentUnder8oC) {
		this.yearlyInvestmentUnder8oC = yearlyInvestmentUnder8oC;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	@Override
	public String toString() {
		return "Associate [associateId=" + associateId + ", yearlyInvestmentUnder8oC=" + yearlyInvestmentUnder8oC
				+ ", firstName=" + firstName + ", lastname=" + lastname + ", department=" + department
				+ ", designation=" + designation + ", pancard=" + pancard + ", emailid=" + emailid + ", salary="
				+ salary + ", bankdetails=" + bankdetails + "]";
	}
	

}





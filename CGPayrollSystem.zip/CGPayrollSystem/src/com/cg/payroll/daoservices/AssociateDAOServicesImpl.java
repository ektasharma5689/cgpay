package com.cg.payroll.daoservices;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.util.PayRollDBUtil;

import java.util.ArrayList;
import java.util.List;

public class AssociateDAOServicesImpl implements AssociateDAO {
	@Override
	public Associate save(Associate associate) {
		associate.setAssociateId(PayRollDBUtil.getASSOCIATE_ID_COUNTER());
		PayRollDBUtil.associates.put(associate.getAssociateId(), associate);
		return associate;
	}
	@Override
	public boolean update(Associate associate) {
		return false;
	}
	@Override
	public Associate findOne(int associateId) {
		return PayRollDBUtil.associates.get(associateId);
	}
	@Override
	public List<Associate> findAll() {
		return new ArrayList<>(PayRollDBUtil.associates.values());
	}
	@Override
	public List<Associate> getAllAssociatesDetail() {
		return null;
	}
}

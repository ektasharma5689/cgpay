package com.cg.payroll.exceptions;

public class Exceptions {

}

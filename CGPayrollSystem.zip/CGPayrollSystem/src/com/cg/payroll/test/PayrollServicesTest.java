package com.cg.payroll.test;
import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayRollDBUtil;

//import junit.framework.Assert;
public class PayrollServicesTest {
private static PayrollServices services; 
@BeforeClass
	public  static void setUpTestEnv() {
		services=new PayrollServicesImpl();
	}
	@Before
	public void setUpTestData() {
		Associate associate1=new Associate(101, 500, "Ekta", "Sharma", "IT", "Manager", "12385535", "ektasharma5689@g,mail.com", 
				new Salary(35000,1800,2000),new BankDetails(12345,"axis","asd456"));
Associate associate2=new Associate(102, 700, "Eksh", "Sharma", "Management", "Director", "12385534", "eshsharma5689@g,mail.com",
new Salary(31000,1200,3000),new BankDetails(123455,"hdfc","as456"));

PayRollDBUtil.associates.put(associate1.getAssociateId(), associate1);
PayRollDBUtil.associates.put(associate2.getAssociateId(), associate2);
PayRollDBUtil.ASSOCIATE_ID_COUNTER=102;
	}
	@Test(expected=AssociateDetailNotFoundException.class)
	public void testGetAssociateDetailForInvalidAssociateId() throws AssociateDetailNotFoundException {
		services.getAssociateDetails(12343);
	}
	@Test
	public void testGetAssociateDetailsForValidAssociateId() throws AssociateDetailNotFoundException{
		Associate expectedAssociate=new Associate(101, 500, "Ekta", "Sharma", "IT", "Manager", "12385535", "ektasharma5689@g,mail.com", 
				new Salary(35000,1800,2000),new BankDetails(12345,"axis","asd456"));
		Associate actualAssociate= services.getAssociateDetails(101);
		Assert.assertEquals(expectedAssociate, actualAssociate);
	}
	@Test
	public void testAcceptAssociateDetailsForValidData() {
		int expectedId=103;
		int actualId=services.acceptAssociateDetails("ehfrr", "jhgtff","dsfgs@", "hygdh", "daytha","fe76jikuhyy", 545485, 567, 324, 48548, 548646477, "dstry", "isryueihy");
		Assert.assertEquals(expectedId, actualId);
	}
	@Test(expected=AssociateDetailNotFoundException.class)
	public void testCalculateNetSalaryForInvalidAssociateId() throws AssociateDetailNotFoundException{
		services.calculateNetSalary(1434);
	}
/*	@Test
	public void testCalculateNetSalaryForValidAssociateId() throws AssociateDetailNotFoundException{
		int expectedNetSalary=0;
		int actualNetSalary=services.calculateNetSalary(102);
		Assert.assertEquals(expectedNetSalary, actualNetSalary);
	}*/
	
	@Test
	public void testGetAllAssociateDetails() {
	
	Associate associate1=new Associate(101, 500, "Ekta", "Sharma", "IT", "Manager", "12385535", "ektasharma5689@g,mail.com", 
			new Salary(35000,1800,2000),new BankDetails(12345,"axis","asd456"));
Associate associate2=new Associate(102, 700, "Eksh", "Sharma", "Management", "Director", "12385534", "eshsharma5689@g,mail.com",
new Salary(31000,1200,3000),new BankDetails(123455,"hdfc","as456"));
ArrayList<Associate> expectedAssociateList=new ArrayList<>();
expectedAssociateList.add(associate1);
expectedAssociateList.add(associate2);
ArrayList<Associate>actualAssociateList=(ArrayList<Associate>)services.getAllAssociatesDetails();
Assert.assertEquals(expectedAssociateList, actualAssociateList);
}
	@After
	public void tearDownTestData() {
		PayRollDBUtil.associates.clear();
		PayRollDBUtil.ASSOCIATE_ID_COUNTER=100;
	}
	@AfterClass
	public static void tearDownTestEnv() {
	services=null;
	}	
}

package com.cg.payroll.test;
import static org.junit.Assert.*;

import java.util.ArrayList;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class PayrollServicesTestEasyMock {
private static PayrollServices payrollservices;
private static AssociateDAO mockAssociateDao; 
	@BeforeClass
	public static void setUpTestEnv(){
		mockAssociateDao=EasyMock.mock(AssociateDAO.class);
		payrollservices= new PayrollServicesImpl(mockAssociateDao);
	}
@Before
public void setUpTestMockData() {
	Associate associate1=new Associate(101, 500, "Ekta", "Sharma", "IT", "Manager", "12385535", "ektasharma5689@g,mail.com", 
			new Salary(35000,1800,2000),new BankDetails(12345,"axis","asd456"));
Associate associate2=new Associate(102, 700, "Eksh", "Sharma", "Management", "Director", "12385534", "eshsharma5689@g,mail.com",
            new Salary(31000,1200,3000),new BankDetails(123455,"hdfc","as456"));
Associate associate3=new Associate( 1700, "ksh", "Sharm", "Managemen", "irector", "12385534", "eshsharma5689@g,mail.com",
        new Salary(31000,1200,3000),new BankDetails(12345,"hdf","acs456"));
ArrayList<Associate> associateList=new ArrayList<>();
associateList.add(associate1);
associateList.add(associate2);
EasyMock.expect(mockAssociateDao.save(associate3)).andReturn(associate3);

EasyMock.expect(mockAssociateDao.findOne(101)).andReturn(associate1);
EasyMock.expect(mockAssociateDao.findOne(102)).andReturn(associate2);
EasyMock.expect(mockAssociateDao.findOne(170)).andReturn(null);
EasyMock.expect(mockAssociateDao.findAll()).andReturn(associateList);
EasyMock.replay(mockAssociateDao);
		}
	@Test(expected=AssociateDetailNotFoundException.class)
	public void testGetAssociateDataForInvalidAssociateId1()throws AssociateDetailNotFoundException{
		payrollservices.getAssociateDetails(1234);
		EasyMock.verify(mockAssociateDao.findOne(1234));
	}
	@Test
	public void testGetAssociateDataForInvalidAssociateId()throws AssociateDetailNotFoundException{
		Associate expectedAssociate=new Associate(101, 500, "Ekta", "Sharma", "IT", "Manager", "12385535", "ektasharma5689@g,mail.com", 
				new Salary(35000,1800,2000),new BankDetails(12345,"axis","asd456"));
	Associate actualAssociate=payrollservices.getAssociateDetails((101));
	assertEquals(expectedAssociate,actualAssociate);
	EasyMock.verify(mockAssociateDao.findOne(1234));
	}
	@After
	public static void tearDownTestMockData() {
		EasyMock.resetToDefault(mockAssociateDao);
	}
@AfterClass
public static void tearDownTestEnv() {
	mockAssociateDao=null;
	payrollservices=null;
}
}

